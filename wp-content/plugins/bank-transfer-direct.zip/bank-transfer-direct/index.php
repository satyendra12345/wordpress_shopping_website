<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/1.3.8/FileSaver.js"></script>

    <script src="./qrcode.js" charset="utf-8"></script>
    <title>Universal UPI QR Code Generator</title>
    <link rel="stylesheet" href="./index.css">
    <link rel="stylesheet" media="print" href="./print.css">
  </head>
  <body>
    <div id="fb-root"></div>
    <script>(function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = 'https://connect.facebook.net/mr_IN/sdk.js#xfbml=1&version=v3.0';
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>


    <div class="topBar shouldBeHiddenOnPrint">
      <h1 class="display-4">Universal UPI QR Code Generator</h1>
      <p class="lead">Free QR Code for <b>Current Account</b> & <b>Saving Account</b></p>
    </div>
    <div class="mainContent">
      <div class="shouldBeHiddenOnPrint">
        <h2>Features</h2>
        <ul class="list-group">
          <li class="list-group-item">0% MDR, 0% transaction fees</li>
          <li class="list-group-item">VPA is NOT needed for for QR generation</li>
          <li class="list-group-item">UPI registration is NOT needed for QR generation</li>
          <li class="list-group-item">UPI app is NOT needed for QR generation</li>
          <li class="list-group-item">Work both on Current Account and Savings Accounts</li>
        </ul>
        <div class="card-deck">
          <div class="bg-light card mb-3">
            <div class="card-body">
              <h5 class="card-title">Business</h5>
              <hr>
              <p class="card-text">Create Free QR for <b>Current Account</b></p>
            </div>
          </div>
          <div class="bg-light card mb-3">
            <div class="card-body">
              <h5 class="card-title">Personal</h5>
              <hr>
              <p class="card-text">Create Free QR for <b>Saving Account</b></p>
            </div>
          </div>
          <div class="bg-light card mb-3">
            <div class="card-body">
              <h5 class="card-title">How?</h5>
              <hr>
              <p class="card-text">All you need Account Number and IFSC Code to get the QR Code.</p>
            </div>
          </div>
        </div>
        <h2>Step 1 - Fill up the Bank Details & click Generate button</h1>
        <div class="card container-fluid" style="max-width: 400px;">
          <div class="card-body">
            <h5 class="card-title">Bank Account Info</h5>

            <div class="form-group mb-3">
              <label for="accName">Account Name</label>
              <input type="text" class="smallinput form-control" id="accName" placeholder="">
            </div>
            <div class="form-group mb-3">
              <label for="accNumber">Account Number</label>
              <input type="text" class="smallinput form-control" id="accNumber" placeholder="">
            </div>
            <div class="form-group mb-3">
              <label for="accIFSC">IFSC Code</label>
              <input type="text" class="smallinput form-control" id="accIFSC" placeholder="">
            </div>
            <button type="button" id="generateButton" class="btn btn-block btn-primary btn-lg">Generate QR Code</button>
          </div>
        </div>
        <h2>Step 2 - Click on "Download QR Image"</h1>
      </div>
      <div id="A4Page" class="A4Page">
          <img class="upiLogo" src="./upi-icon-black.png" alt="">
          <div style="font-size: 7mm;font-weight: normal;">BHIM UPI Payments Accepted at</div>
          <div id="accNameReplace" style="font-size: 6mm;font-weight: bold;color: #54566f;font-family: sans-serif;">SAMPLE ACC NAME</div>
          <div class="qrBoxOuter">
            <div id="box1"></div>
          </div>
          <div id="accInfo" style="font-size: 5mm;font-weight: bold;color: #54566f;font-family: sans-serif;">
            Account Number : <span id="accNumberReplace">SAMPLE ACC NUMBER</span>, IFSC Code: <span id="accIFSCReplace">SAMPLE IFSC CODE XYZ</span>
          </div>
          <div style="font-size: 7mm;font-weight: normal;padding: 2mm;">Scan and Pay using any UPI supported Apps</div>
          <div class="hrline"></div>
          <img style="width:85%;margin-top: 4mm;" src="./apps.png" alt="">
          <div style="font-size: 5mm;font-weight: normal;background: azure;padding: 2mm;border: 1px solid gray;">Generated By : https://nsisodiya.github.io/Universal-UPI-QR-Code-Generator</div>
      </div>
      <button type="button" id="DownloadQrImage" class="shouldBeHiddenOnPrint btn btn-primary btn-lg">Download QR Image</button>
    </div>

    <div class="FBBOX shouldBeHiddenOnPrint">
      <div class="fb-share-button" data-href="https://nsisodiya.github.io/Universal-UPI-QR-Code-Generator/" data-layout="button_count" data-size="large" data-mobile-iframe="true"><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fnsisodiya.github.io%2FUniversal-UPI-QR-Code-Generator&amp;src=sdkpreparse" class="fb-xfbml-parse-ignore">Share</a></div>
      <div class="fb-comments" data-href="https://nsisodiya.github.io/Universal-UPI-QR-Code-Generator/" data-numposts="5"></div>
    </div>
  <script src="./index.js" charset="utf-8"></script>
  </body>
</html>
